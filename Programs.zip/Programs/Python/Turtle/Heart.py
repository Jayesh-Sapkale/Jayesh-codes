import turtle

heart = turtle.Turtle()
heart.pensize(5)
heart.speed(5)


def draw(x, y):
    heart.penup()
    heart.goto(x, y)
    heart.pendown()


draw(-450, 0)
heart.begin_fill()
heart.left(90)
heart.forward(200)
heart.right(90)
heart.forward(900)
heart.right(90)
heart.forward(400)
heart.right(90)
heart.forward(900)
heart.right(90)
heart.forward(200)

heart.end_fill()


# Heart characteristics
heart.color("#a83f39")


draw(-250, 100)

# letter I
heart.left(90)
heart.left(90)
heart.forward(200)
heart.right(90)
heart.forward(100)
heart.backward(200)
heart.forward(100)
heart.right(90)
heart.forward(200)
heart.right(90)
heart.forward(100)
heart.backward(200)


draw(0, -125)

# Heart
heart.begin_fill()
heart.left(50)
heart.forward(180)
heart.circle(70, 200)
heart.right(140)
heart.circle(70, 201.5)
heart.forward(180)
heart.end_fill()

draw(160, 125)

# Letter U
heart.right(42)
heart.forward(200)
heart.circle(60, 90)
heart.forward(70)
heart.circle(60, 90)
heart.forward(200)

turtle.done()
