package previous;

import java.util.*;

public class Input {

    public static void main(String args[]) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter two numbers: ");

            int a = sc.nextInt();
            int b = sc.nextInt();

            System.out.println("Sum: " + (a + b));
        }
    }

}
