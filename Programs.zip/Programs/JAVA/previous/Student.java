package previous;

import java.util.*;

public class Student {

    int rno;
    String nm;
    float res;

    void get() {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter Student's Roll number, Name and Result");

            rno = sc.nextInt();
            nm = sc.next();
            res = sc.nextFloat();
        }
    }

    void put() {
        System.out.println("Student Details\n" + "Roll No: " + rno + "\nName: " + nm + "\nResult: " + res);
    }

    public static void main(String[] args) {

        Student s1 = new Student();

        s1.get();
        s1.put();
    
    }
}

