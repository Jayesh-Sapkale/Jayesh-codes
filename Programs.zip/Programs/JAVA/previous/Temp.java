package previous;

public class Temp {
    public static void main(String arg[]) {
        System.out.println("Hello, World");
    }

}
