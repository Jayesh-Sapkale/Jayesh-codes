package previous;

import java.util.Scanner;

public class ArithmeticSwitch {
    public static void main(String[] args) {

        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter two numbers: ");

            int a = sc.nextInt();
            int b = sc.nextInt();

            System.out.println("Enter your choice\nAdd\nSub\nMul\nDiv");
            String ch = sc.next();

            switch (ch) {
                case "Add":
                    System.out.println("Sum: " + (a + b));
                    break;

                case "Sub":
                    System.out.println("Sub: " + (a - b));
                    break;

                case "Mul":
                    System.out.println("Mul: " + (a * b));
                    break;

                case "Div":
                    System.out.println("Div: " + (a / b));
                    break;

                default:
                    System.out.println("Invalid Choice!");
                    break;
            }
        }

    }
}
