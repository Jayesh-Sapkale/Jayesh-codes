package previous;

import java.util.Scanner;

public class Arr1 {
    public static void main(String args[]) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter length of an array: ");

            int num = sc.nextInt();

            int arr1[] = new int[num];

            System.out.println("Enter Array Elements: ");

            for (int i = 0; i < num; i++) {
                arr1[i] = sc.nextInt();
            }

            System.out.println("Array Elements are: ");

            for (int i = 0; i < num; i++) {
                System.out.print(arr1[i] + " ");
            }
        }
    }
}
