package constructor;

class Student {
    int rno;
    String nm;
    float res;

    // Default constructor
    Student() {
        rno = 1;
        nm = "Jayesh";
        res = 90.4f;

    }

    // Parameterized Constructor 1

    Student(int r, String n, float re) {
        rno = r;
        nm = n;
        res = re;
    }

    // Parameterized Constructor 2
    Student(int r1, float re1, String n1) {
        rno = r1;
        nm = n1;
        res = re1;
    }

    // Parameterized Constructor 3

    Student(int rno, String nm) {
        this.rno = rno;
        this.nm = nm;
        res = 98.6f;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Student[" + " Roll Number: " + rno + ", Name: " + nm + ", Result: " + res + "]";
    }

}

public class Demo1 {

    public static void main(String[] args) {
        Student s1 = new Student();
        Student s2 = new Student(2, "Mayur", 90.1f);
        Student s3 = new Student(3, 98.1f, "Umesh");
        Student s4 = new Student(4, "Mohit");

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);

    }

}
