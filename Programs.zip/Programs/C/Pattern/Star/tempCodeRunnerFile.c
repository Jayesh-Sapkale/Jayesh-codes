for (int k = rows; k >=i; k--)
        // {
        //     printf("*");
        // }