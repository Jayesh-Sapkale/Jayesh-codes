/*

*                 *
* *             * *
* * *         * * *
* * * *     * * * *
* * * * * * * * * *

*/

#include <stdio.h>

int main()
{
    int rows = 5;

    for (int i = 1; i <= rows; i++)
    {
        for (int k = 1; k <= i; k++)
        {
            printf("*");
        }
        for (int j = 1; j <= (2) * (rows - i); j++)
        {
            printf(" ");
        }
        for (int k = 1; k <= i; k++)
        {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}