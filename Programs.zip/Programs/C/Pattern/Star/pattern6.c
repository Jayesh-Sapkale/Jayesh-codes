#include <stdio.h>

int main()
{
    int num = 6;

    char alphabets[] = {'A', 'B', 'C', 'D', 'E', 'F'};

    for (int i = 0; i < num; i++)
    {
        for (int j = 0; j < i+1; j++)
        {
            printf("%c ", alphabets[j]);
        }
        printf("\n");
    }

    return 0;
}