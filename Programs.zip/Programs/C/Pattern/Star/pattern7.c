/*
 * * * * *
   * * * *
     * * *
       * *
         *
 */

#include <stdio.h>

int main()
{
    int rows = 5;

    for (int i = rows; i >= 1; i--)
    {
        for (int k = rows; k > i; k--)
        {
            printf(" ");
        }
        for (int j = rows; j > rows - i; j--)
        {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}