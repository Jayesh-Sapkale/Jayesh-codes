#include <stdio.h>

int main()
{
    int m, n;

    printf("Enter two numbers: ");
    scanf("%d %d", &m, &n);

    printf("Printing %d X %d matrix of *: \n", m, n);
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("* ");
        }
        printf("\n");
    }

    return 0;
}