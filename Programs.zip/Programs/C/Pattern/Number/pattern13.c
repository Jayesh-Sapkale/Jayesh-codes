/*

 1    1
  2  2
   3 
 4  4 
3    3

*/


#include<stdio.h>

int main()
{
    int rows = 5;

    for (int i = 1; i <= rows;i++)
    {
        
    }

        return 0;
}