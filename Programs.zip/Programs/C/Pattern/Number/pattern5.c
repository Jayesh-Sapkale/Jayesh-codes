/*

        1
      1 2 3
    1 2 3 4 5
  1 2 3 4 5 6 7
1 2 3 4 5 6 7 8 9
  1 2 3 4 5 6 7
    1 2 3 4 5
      1 2 3
        1

*/

#include <stdio.h>

int main()
{
    int rows = 5;

    for (int i = 1; i <= rows; i++)
    {
        for (int k = rows - i; k >=0; k--)
        {
            printf(" ");
        }

        for (int j = 1; j <= (2 * i) - 1; j++)
        {
            printf("%d", j);
        }
        printf("\n");
    }
    for (int i = rows-1; i >= 1; i--)
    {
        for (int k = rows - i; k >=0; k--)
        {
            printf(" ");
        }

        for (int j = 1; j <= (2 * i) - 1; j++)
        {
            printf("%d", j);
        }
        printf("\n");
    }

    return 0;
}