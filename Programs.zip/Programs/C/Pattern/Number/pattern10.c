/*
            1
          2 3
        3 4 5
      4 5 6 7
    5 6 7 8 9

*/

#include <stdio.h>

int main()
{
    int rows = 5;

    for (int i = 1; i <= rows; i++)
    {
        for (int k = rows - i; k > 0; k--)
        {
            printf(" ");
        }
        for (int j = i; j <= (2 * i) - 1; j++)
        {
                printf("%d", j);
        }
        printf("\n");
    }

    return 0;
}
