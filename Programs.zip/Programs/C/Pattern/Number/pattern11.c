/*


2
4 3
6 5 4
8 7 6 5

*/

#include <stdio.h>

int main()
{
    int rows = 5;

    for (int i = 1; i < rows; i++)
    {
        for (int j = i * 2; j > i; j--)
        {
            printf("%d ", j);
        }

        printf("\n");
    }

    return 0;
}