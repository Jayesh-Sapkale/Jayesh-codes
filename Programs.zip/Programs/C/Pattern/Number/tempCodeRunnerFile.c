for (int j = 1; j <=i; j++)
        {
            printf("%d ", j);
        }