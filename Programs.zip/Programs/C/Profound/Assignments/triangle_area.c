#include<stdio.h>

int main()
{
    float h, b,area;

    printf("Enter height and base value: ");
    scanf("%f%f", &h, &b);

    area = (h * b) / 2;

    printf("Area of a triangle is: %.1f\n", area);
    return 0;
}