#include <stdio.h>

int main()
{
    float total = 0, average = 0;

    float marks[5];

    printf("Enter marks for 5 subjects: ");

    for (int i = 0; i < 5; i++)
    {
        scanf("%f", &marks[i]);
    }

    for (int i = 0; i < 5; i++)
    {
        total += marks[i];
        average = total / 5;
    }

    printf("Total marks are: %.1f\n", total);
    printf("Average marks are: %.1f\n", average);

    return 0;
}