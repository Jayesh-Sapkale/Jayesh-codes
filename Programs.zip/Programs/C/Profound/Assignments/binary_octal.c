#include <stdio.h>
#include <math.h>

int main()
{
    long int num;
    int oct[100], rem = 0, temp, count = 0, result = 0;

    printf("Enter a binary number: ");
    scanf("%d", &num);

    temp = num;

    while (num > 0)
    {
        rem = num % 10;
        result += rem * (pow(2, count));
        count++;
        num = num / 10;
    }

    num = temp;
    int i = 0;
    while (result > 0)
    {
        rem = result % 8;
        result = result / 8;

        oct[i] = rem;
        i++;
    }

    count = i;
    count--;
    printf("Octal of %ld is: ", num);

    for (int i = count; i >= 0; i--)
    {
        printf("%d", oct[i]);
    }

    return 0;
}