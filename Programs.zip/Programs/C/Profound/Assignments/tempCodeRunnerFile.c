 printf("%d ", rem);
        printf("%d ", temp);