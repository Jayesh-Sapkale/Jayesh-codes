#include <stdio.h>

int main()
{
    float a, b;
    char choice;

    printf("Enter two numbers: ");
    scanf("%f%f", &a, &b);

    printf("Enter + for addition\nEnter - for subtraction\nEnter * for multiplication\nEnter / for division\n: ");
    scanf(" %c", &choice);

    printf("Your choice is: %c\n", choice);

    switch (choice)
    {

    case '+':
        printf("Addition of %.1f and %.1f is: %.1f\n", a, b, a + b);
        break;

    case '-':
        printf("Subtraction of %.1f and %.1f is: %.1f\n", a, b, a - b);
        break;
    case '*':
        printf("Multiplication of %.1f and %.1f is: %.1f\n", a, b, a * b);
        break;
    case '/':
        printf("Division of %.1f and %.1f is: %.1f\n", a, b, a / b);
        break;
    default:
        printf("Invalid choice!\n");
        break;
    }

    return 0;
}