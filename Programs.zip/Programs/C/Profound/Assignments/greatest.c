#include <stdio.h>

int greatest(int, int, int);

int main()
{
    int a, b, c;

    printf("Enter three numbers: ");
    scanf("%d%d%d", &a, &b, &c);

    greatest(a, b, c);

    return 0;
}

int greatest(int a, int b, int c)
{
    if (a > b && a > c)
    {
        printf("greatest number is: %d\n", a);
        return a;
    }
    else if (b > a && b > c)
    {
        printf("greatest number is: %d\n", b);
        return b;
    }
    else if (a == b && b == c)
    {
        printf("a, b and c are equal\n");
    }
    else
    {
        printf("greatest number is: %d\n", c);
        return c;
    }
}