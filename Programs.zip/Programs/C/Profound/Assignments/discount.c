#include <stdio.h>

int main()
{
    int cp;
    char choice;

    printf("Enter a cost price: ");
    scanf("%d", &cp);

    printf("Are you a student press y for yes and n for no: ");
    scanf("%c ", &choice);

    if (cp > 500 && choice == 'y')
    {
        printf("You got discount of 10\%\n");
    }
    else if (cp > 500 && choice == 'n')
    {
        printf("You got discount of 8\%\n");
    }
    else
    {
        printf("You got discount of 2\%\n");
    }

    return 0;
}