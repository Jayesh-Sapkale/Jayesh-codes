#include <stdio.h>

const int pi = 3.14;

void cylinder()
{
    int r, h;

    printf("Enter radius of a cylinder: ");
    scanf("%d", &r);
    printf("Enter height of a cylinder: ");
    scanf("%d", &h);
    float result = pi * r * r * h;
    printf("Volume of a cylinder is: %.2f", result);
}

int main()
{
    cylinder();

    return 0;
}