#include <stdio.h>

int main()
{
    int choice, num, year;

    printf("Enter 1 to find square and cube of a number\nEnter 2 to find leap year\n: ");
    scanf("%d", &choice);

    switch (choice)
    {
    case 1:
        printf("Enter a number: ");
        scanf("%d", &num);

        printf("Square of %d is: %d\nCube of %d is: %d\n", num, num * num, num, num * num * num);
        break;
    case 2:
        printf("Enter a year: ");
        scanf("%d", &year);

        if (year % 400 == 0)
        {
            printf("%d is a leap year\n", year);
        }
        else if (year % 4 == 0 && year % 100 != 0)
        {
            printf("%d is not a leap year\n", year);
        }
        else
        {
            printf("%d is not a leap year\n", year);
        }
        break;
    default:
        printf("Invalid choice!\n");
        break;
    }

    return 0;
}