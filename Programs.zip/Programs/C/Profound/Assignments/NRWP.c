#include <stdio.h>

const int pi = 3.14;

void cylinder(int r, int h)
{
    float result = pi*r*r*h;
    printf("Volume of a cylinder is: %.2f", result);
}

int main()
{
    int r, h;
    float result;

    printf("Enter radius of a cylinder: ");
    scanf("%d", &r);
    printf("Enter height of a cylinder: ");
    scanf("%d", &h);

    cylinder(r, h);

    return 0;
}