#include <stdio.h>

int main()
{
    float c, f;

    printf("Enter temperature in degree Fahrenheit: ");
    scanf("%f", &f);
    c = ((f - 32) * 5) / 9;

    printf("Temperature in Celcius is: %.1f", c);

    return 0;
}