#include <stdio.h>

int main()
{
    int percent;

    printf("Enter your percentage: ");
    scanf("%d", &percent);

    if (percent > 70)
    {
        printf("Grade A\n");
    }
    else if (percent <= 70 && percent > 60)
    {
        printf("Grade B+\n");
    }
    else if (percent <= 60 && percent > 45)
    {
        printf("Grade B\n");
    }
    else if (percent <= 45 && percent >= 35)
    {
        printf("Grade C\n");
    }
    else
    {
        printf("Fail\n");
    }

    return 0;
}