#include <stdio.h>

int fibo(int num)
{
    if (num <= 1)
    {
        return 1;
    }
    
}

int main()
{
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    int arr[num];

    arr[0] = 0;
    arr[1] = 1;

    printf("%d %d ", arr[0], arr[1]);

    for (int i = 2; i < num; i++)
    {
        arr[i] = arr[i - 1] + arr[i - 2];
        printf("%d ", arr[i]);
    }

    return 0;
}