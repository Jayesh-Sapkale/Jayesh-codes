/*

1   5
2   4
4   2
5   1
*/

#include <stdio.h>

int main()
{
    int num = 5;

    for (int i = 1, j = num; i <= num, j >= 1; i++, j--)
    {
        if (i == 3 && j == 3)

            continue;
        printf("%d\t%d", i, j);

        printf("\n");
    }

    return 0;
}