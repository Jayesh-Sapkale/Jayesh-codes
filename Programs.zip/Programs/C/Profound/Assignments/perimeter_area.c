#include <stdio.h>
void peri_area_square(float);
void peri_area_rectangle(float, float);

int main()
{
    float length, breadth;

    printf("Enter length and breadth: ");
    scanf("%f%f", &length, &breadth);
    peri_area_rectangle(length, breadth);
    peri_area_square(length);

    return 0;
}

void peri_area_rectangle(float a, float b)
{
    float perimeter, area;

    perimeter = 2 * (a + b);
    area = a * b;

    printf("Area of a rectangle is: %.1f\n", area);
    printf("Perimeter of a rectangle is: %.1f\n", perimeter);
}

void peri_area_square(float a)
{
    float perimeter, area;

    perimeter = 4 * a;
    area = a * a;

    printf("Area of a Square is: %.1f\n", area);
    printf("Perimeter of a Square is: %.1f\n", perimeter);
}