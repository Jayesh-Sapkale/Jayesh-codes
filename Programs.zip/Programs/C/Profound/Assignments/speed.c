#include <stdio.h>

int main()
{
    float s, d, t;

    printf("Enter distance in kilo meters: ");
    scanf("%f", &d);
    printf("Enter time in hours: ");
    scanf("%f", &t);

    s = d / t;

    printf("Speed is: %.1f km/h", s);

    return 0;
}