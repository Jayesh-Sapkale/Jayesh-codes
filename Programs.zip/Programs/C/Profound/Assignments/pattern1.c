/*
    1 2 3 4 5 6 7 8 9

1           *
2         * * *
3       * * * * *
4     * * * * * * *
5   * * * * * * * * *

*/

#include <stdio.h>

int main()
{
    int rows = 5;

    for (int i = 1; i <= rows; i++)
    {
        for (int j = 1; j <= rows - i; j++)
        {
            printf(" ");
        }
        for (int k = 1; k <= i; k++)
        {
            printf("*");
        }
        for (int k = 0; k < i - 1; k++)
        {
            printf("*");
        }

        printf("\n");
    }
    printf("\nAnother method for same pattern\n");

    for (int i = 1; i <= rows; i++)
    {
        for (int j = 1; j <= rows - i; j++)
        {
            printf(" ");
        }

        for (int k = 1; k <= (2 * i) - 1; k++)
        {
            printf("*");
        }

        printf("\n");
    }

    return 0;
}