#include <stdio.h>

int is_even(int num)
{
    if (num % 2 == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int main()
{
    int num, rem, sum = 0, temp;

    printf("Enter a number: ");
    scanf("%d", &num);

    temp = num;
    while (num > 0)
    {
        rem = num % 10;
        if (is_even(rem))
        {
            sum += rem;
        }
        num = num / 10;
    }

    num = temp;

    printf("Sum of all even numbers in %d is: %d\n", num, sum);

    return 0;
}