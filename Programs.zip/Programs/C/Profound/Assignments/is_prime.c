#include <stdio.h>

int is_prime(int num)
{
    int count;
    if (num == 0)
    {
        printf("Enter number greater than 0\n", num);
        return 0;
    }
    else if (num == 1)
    {
        printf("%d is neither prime nor composite number\n", num);
        return 0;
    }
    else
    {
        for (int i = 2; i < num; i++)
        {
            if (num % i == 0)
            {
                count = 0;
            }
        }

        if (count == 0)
        {
            printf("%d is a composite number\n", num);
            return 0;
        }
        else
        {
            printf("%d is a prime number\n", num);
            return 1;
        }
    }
}

int main()
{
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    is_prime(num);

    return 0;
}