/*

1 1 1 2
3 2 2 2
3 3 3 4

*/


#include <stdio.h>

int main()
{
    int rows = 3;

    for (int i = 1; i <= rows; i++)
    {
        for (int j = 1; j <= rows + 1; j++)
        {
            printf("%d",)
        }
        printf("\n");
    }

    return 0;
}