#include <stdio.h>

const int pi = 3.14;

int cylinder()
{
    int r, h;

    printf("Enter radius of a cylinder: ");
    scanf("%d", &r);
    printf("Enter height of a cylinder: ");
    scanf("%d", &h);
    float result = pi * r * r * h;
    printf("Volume of a cylinder is: %.2f", result);

    return 0;
}

int main()
{
    cylinder();

    return 0;
}