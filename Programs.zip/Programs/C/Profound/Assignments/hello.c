// linking section
#include <stdio.h>

// Declaration section
int main()
{
    printf("\nHello, World!\n"); //Excecutable section

    return 0;
}