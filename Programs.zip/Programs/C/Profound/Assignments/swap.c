#include <stdio.h>

int main()
{
    int a, b, temp;

    printf("Enter two numbers: ");
    scanf("%d%d", &a, &b);

    printf("Value of a = %d and b = %d before swapping\n", a, b);
    temp = a;
    a = b;
    b = temp;
    printf("Value of a = %d and b = %d after swapping using third variable\n", a, b);

    a = a + b;
    b = a - b;
    a = a - b;

    printf("Value of a = %d and b = %d after swapping without using third variable\n", a, b);

    return 0;
}