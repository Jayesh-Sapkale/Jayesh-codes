#include <stdio.h>

int main()
{
    int num, rem = 0, bin[100], temp, count = 0;

    printf("Enter a Decimal number: ");
    scanf("%d", &num);

    if (num == 0)
    {
        printf("0 0 0 0");
    }

    else
    {

        temp = num;

        while (num > 0)
        {
            rem = num % 2;
            num = num / 2;
            bin[count] = rem;
            count++;
        }
        num = temp;
        // printf("count is: %d\n", count);

        while (count % 4 != 0)
        {
            bin[count] = 0;
            count++;
        }
        count--;

        printf("Binary of %d is: ", num);
        for (int i = count; i >= 0; i--)
        {
            printf("%d ", bin[i]);
        }
    }
    return 0;
}