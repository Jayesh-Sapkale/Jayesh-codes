// WAP to check whether a person is eligible for voting or not

#include <stdio.h>

void main()
{
    int age;

    printf("Enter your age: ");
    scanf("%d", &age);

    if (age >= 18)
    {
        printf("You can vote\n");
    }
    else
    {
        printf("You can't vote\n");
    }
}