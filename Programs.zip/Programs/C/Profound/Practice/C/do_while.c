// WAP to demonstrate do-while loop.

#include <stdio.h>

void main()
{
    int i = 10;

    do
    {
        printf("%d\n", i);
    } while (i >= 50);
}