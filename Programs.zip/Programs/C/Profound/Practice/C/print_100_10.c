// WAP to print the numbers from 100 to 10.

#include <stdio.h>

void main()
{

    for (int i = 100; i >= 10; i--)
    {
        printf("%d ", i);
    }
}