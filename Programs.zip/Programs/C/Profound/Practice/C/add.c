// WAP to calculate sum of two integers

#include <stdio.h>

void main()
{
    int a, b;

    printf("Enter two integers: ");
    scanf("%d%d", &a, &b);

    printf("Sum of two integers is: %d\n", a + b);
}