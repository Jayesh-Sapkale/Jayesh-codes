// WAP to print sum of odd numbers between given range.

#include <stdio.h>

void main()
{
    int a, b, sum = 0;

    printf("Enter a range: ");
    scanf("%d%d", &a, &b);

    for (int i = a; i <= b; i++)
    {
        if (i % 2 == 0)
        {
            continue;
        }
        sum += i;
    }

    printf("\nSum of odd numbers between %d and %d is: %d\n", a, b, sum);
}