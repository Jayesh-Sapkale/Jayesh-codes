// WAP to print table of a given number using while loop.

#include <stdio.h>

void main()
{
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    int i = 1;

    while (i <= 10)
    {
        printf("%d X %d = %d\n", num, i, num * i);
        i++;
    }
}