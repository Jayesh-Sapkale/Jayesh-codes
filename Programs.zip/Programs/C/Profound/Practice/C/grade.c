// WAP to print particular grade based on student's marks.

#include <stdio.h>

void main()
{
    int marks;

    printf("Enter your marks: ");
    scanf("%d", &marks);

    if (marks >= 75)
    {
        printf("Distinction\n");
    }
    else if (marks < 75 && marks >= 65)
    {
        printf("First Class\n");
    }
    else if (marks < 65 && marks >= 55)
    {
        printf("Higher Second Class\n");
    }
    else if (marks < 55 && marks >= 45)
    {
        printf("Second Class\n");
    }
    else if (marks < 45 && marks >= 35)
    {
        printf("Third Class\n");
    }
    else
    {
        printf("Fail\n");
    }
}