// WAP to print the pattern below

/*

1   5
2   4
4   2
5   1

*/

#include <stdio.h>

void main()
{
    for (int i = 1, j = 5; i <= 5, j >= 1; i++, j--)
    {
        if (i == 3 && j == 3)
        {
            continue;
        }
        printf("%d\t%d\n", i, j);
    }
}