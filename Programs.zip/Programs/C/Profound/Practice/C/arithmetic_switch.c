// WAP to perform arithmetic operations on two integers using switch case.

#include <stdio.h>

void main()
{
    int a, b;
    char ch;

    printf("Enter two numbers: ");
    scanf("%d%d", &a, &b);

    printf("Enter your choice: ");
    scanf(" %c", &ch);

    switch (ch)
    {
    case '+':
        printf("Sum of %d and %d is: %d\n", a, b, a + b);
        break;
    case '-':
        printf("Difference of %d and %d is: %d\n", a, b, a - b);
        break;
    case '*':
        printf("Product of %d and %d is: %d\n", a, b, a * b);
        break;
    case '/':
        printf("Division of %d and %d is: %d\n", a, b, a / b);
        break;
    case '%':
        printf("Modulus of %d and %d is: %d\n", a, b, a % b);
        break;
    default:
        printf("INVALID CHOICE\n");
        break;
    }
}