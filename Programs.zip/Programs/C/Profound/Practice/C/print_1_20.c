// WAP to print the numbers from 1 to 20.

#include <stdio.h>

void main()
{
    int i = 1;

    while (i <= 20)
    {
        printf("%d ", i);
        i++;
    }
}