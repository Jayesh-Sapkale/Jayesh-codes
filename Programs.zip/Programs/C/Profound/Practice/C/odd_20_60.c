// WAP to print odd numbers between 20 to 60.

#include <stdio.h>

void main()
{
    for (int i = 20; i <= 60; i++)
    {
        if (i % 2 != 0)
        {
            printf("%d ", i);
        }
    }
}