#include <stdio.h>
#include <math.h>

int main()
{
    double a, b, c, result, root1, root2, imag, real;

    printf("Enter quadratic euations: \n");
    printf("a: ");
    scanf("%lf", &a);
    printf("b: ");
    scanf("%lf", &b);
    printf("c: ");
    scanf("%lf", &c);

    printf("Quadratic equation is: %.2lfx + %.2lfx^2 +%.2lf\n", a, b, c);

    result = (b * b) - 4 * a * c;

    printf("Discriminant is: %.1f\n", result);

    if (result > 0)
    {
        root1 = (-b + sqrt(result)) / (2 * a);
        root2 = (-b - sqrt(result)) / (2 * a);
        printf("The roots are real and different.\n");
        printf("The roots are: %.2lf and %.2lf\n", root1, root2);
    }
    else if (result == 0)
    {
        root1 = root2 = -b / (2 * a);
        printf("The roots are real and equal.\n");
        printf("The roots are: %.2lf and %.2lf\n", root1, root2);
    }
    else
    {
        real = -b / (2 * a);
        imag = sqrt(-result) / (2 * a);
        printf("The roots are complex and different.\n");
        printf("The roots are: %.2lf + %.2lfi and %.2lf + %.2lfi\n", real, imag, real, imag);
    }

    return 0;
}