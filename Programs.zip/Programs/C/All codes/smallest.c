#include <stdio.h>

int main()
{
    int num, small;

    printf("Enter number of Elements: \n");
    scanf("%d", &num);
    int arr[num];

    printf("Enter numbers: \n");
    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }

    small = arr[0];

    for (int i = 0; i < num; i++)
    {
        if (arr[i] < small)
        {
            small = arr[i];
        }
    }

    printf("Smallest number is: %d\n", small);

    return 0;
}