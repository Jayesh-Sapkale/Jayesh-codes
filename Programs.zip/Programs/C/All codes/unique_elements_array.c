#include <stdio.h>

int main()
{
    int num, count = 0,temp = 0;

    printf("Enter size of an array: ");
    scanf("%d", &num);

    int arr[num];

    printf("Enter elements of an array: \n");
    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("\nElements of an array are: \n");
    for (int i = 0; i < num; i++)
    {
        printf("%d ", arr[i]);
    }

    printf("\nUnique elements of an array are: \n");
    for (int i = 0; i < num; i++)
    {
        count = 0;
        for (int j = i + 1; j < num; j++)
        {
            if (arr[i] == arr[j])
            {
                temp = arr[i];
                count++;
            }
        }
        if (count == 0 && arr[i] != temp)
        {
            printf("%d ", arr[i]);
        }
    }

    return 0;
}