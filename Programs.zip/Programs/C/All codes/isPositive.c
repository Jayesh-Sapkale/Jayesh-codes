#include <stdio.h>

int main()
{
    int num;

    printf("Enter a number: \n");
    scanf("%d", &num);

    if (num > 0 || num == 0)
    {
        printf("%d is a positive number.\n", num);
    }
    else
    {
        printf("%d is a Negative number.\n", num);
    }

    return 0;
}