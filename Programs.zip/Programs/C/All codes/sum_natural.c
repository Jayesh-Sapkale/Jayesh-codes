#include <stdio.h>

int main()
{
    int num, sum = 0, i = 1;

    printf("Enter a Positive number: \n");
    scanf("%d", &num);

    while (i <= num)
    {
        sum += i;
        ++i;
    }
    printf("Sum of %d natural numbers is: %d\n", num, sum);

    return 0;
}