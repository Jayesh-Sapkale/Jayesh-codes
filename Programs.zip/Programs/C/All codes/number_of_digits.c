#include <stdio.h>

int main()
{
    int num, temp, count = 0;

    printf("Enter a number: ");
    scanf("%d", &num);

    temp = num;

    while (num > 0)
    {
        num = num / 10;
        count++;
    }

    num = temp;

    printf("Total digits in %d are %d", num, count);

    return 0;
}