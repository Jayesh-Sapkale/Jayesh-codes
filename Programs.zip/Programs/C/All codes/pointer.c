#include <stdio.h>

int main()
{
    int num = 50;

    int *ptr;

    ptr = &num;

    printf("value of num is: %d\n", num);
    printf("address of num is: %u\n", &num);
    printf("value of ptr is: %u\n", ptr);
    printf("value at ptr is: %d\n", *ptr);

    return 0;
}