#include <stdio.h>

int main()
{
    int num;

    printf("Enter size of an array: ");
    scanf("%d", &num);

    int arr[num];

    printf("Enter %d elements of an array: \n", num);

    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Elements of the given array are: \n");
    for (int i = 0; i < num; i++)
    {
        printf("%d ", arr[i]);
    }

    for (int i = 0; i < num; i++)
    {
        for (int j = i + 1; j < num; j++)
        {
            if (arr[i] == arr[j])
            {
                for (int k = j; k < num - 1; k++)
                {

                    arr[k] = arr[k + 1];
                }
                num--;
                j--;
            }
        }
    }

    printf("\n-Array after removing duplicate values is: \n");

    for (int i = 0; i < num; i++)
    {
        printf("%d ", arr[i]);
    }

    return 0;
}