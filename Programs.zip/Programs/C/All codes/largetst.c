#include <stdio.h>

int main()
{
    int num, big;

    printf("Enter number of Elements: \n");
    scanf("%d", &num);
    int arr[num];

    printf("Enter numbers: \n");
    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }
    big = 0;
    for (int i = 0; i < num; i++)
    {
        if (arr[i] > big)
        {
            big = arr[i];
        }
    }

    printf("Largest number is: %d\n", big);

    return 0;
}