/*

1 1   1 1   1*1 + 1*2 1*1+1*2   1+2 1+2   3 3
2 2 X 2 2 = 2*1 + 2*2 2*1+2*2 = 2+4 2+4 = 6 6
*/

#include <stdio.h>

int main()
{
    int arr1[3][3],
        result[3][3];

    printf("Enter elements of first array: \n");

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            scanf("%d", &arr1[i][j]);
        }
    }

    printf("\nElements of first array are: \n");
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            printf("%d ", arr1[i][j]);
        }
        printf("\n");
    }

    printf("\nTranspose of the matrix is: \n");

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            result[i][j] = (arr1[j][i]);
            printf("%d ", result[i][j]);
        }

        printf("\n");
    }

    return 0;
}