#include <stdio.h>
int is_prime(int num)
{
    for (int i = 2; (i * i) <= num; i++)
    {
        if (num % i == 0)
        {
            return 0;
        }
        else
            return 1;
    }
}

int main()
{
    int num1, num2;
    printf("Enter two numbers: ");
    scanf("%d%d", &num1, &num2);

    for (int i = num1; i <=  num2; i++)
    {

        if (is_prime(i))
        {
            printf("%d ", i);
        }
    }
    return 0;
}