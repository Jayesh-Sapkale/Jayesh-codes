#include<stdio.h>

int main()
{
    int num;
    printf("Enter a number: \n");
    scanf("%d", &num);

    printf("The number you have entered is: %d", num);


}