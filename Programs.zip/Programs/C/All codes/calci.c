#include <stdio.h>

int main()
{
    int choice, user;

    float num1, num2;

    do
    {
        printf("\nEnter two numbers: ");
        scanf("%f%f", &num1, &num2);

        printf("\nEnter your choice\t\n1.Addition\t\n2.Subtraction\t\n3.Multiplication\t\n4.Division\t\n\nChoice: ");
        scanf("%d", &choice);
        switch (choice)
        {

        case 1:
            printf("Addition is: %.1f\n", num1 + num2);
            break;
        case 2:
            printf("Subtraction is: %.1f\n", num1 - num2);
            break;
        case 3:
            printf("Multiplication is: %.1f\n", num1 * num2);
            break;
        case 4:
            printf("Division is: %.1f\n", num1 / num2);
            break;
        default:
            printf("Invalid choice!\n");
            break;
        }

        printf("Enter 0 to exit and 1 to run again: ");
        scanf("%d", &user);

    } while (user == 1);

    if (user == 0)
    {
        printf("\nPlease visit again!\n");
    }

    return 0;
}