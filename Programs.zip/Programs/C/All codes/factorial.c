#include <stdio.h>

int main()
{
    int num;
    unsigned long long result = 1;

    printf("Enter a number: \n");
    scanf("%d", &num);

    for (int i = num; i >= 1; i--)
    {
        result *= i;
    }

    printf("Factorial of %d is %llu\n", num, result);

    return 0;
}