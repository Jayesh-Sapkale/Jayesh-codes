if (count == 0)
    {
        printf("\nArray is already sorted\n");
    }