#include <stdio.h>

int main()
{
    int num;

    printf("Enter size of an array: ");
    scanf("%d", &num);

    int arr[num];

    printf("Enter elements of an array: \n");
    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }
    printf("Elements of an array are: \n");
    for (int i = 0; i < num; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\nElements of an array in reverse order are: \n");
    for (int i = num - 1; i >= 0; i--)
    {
        printf("%d ", arr[i]);
    }

    return 0;
}