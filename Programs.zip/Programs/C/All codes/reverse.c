#include <stdio.h>

int main()
{
    int num, temp, rem;

    printf("Enter a number: ");
    scanf("%d", &num);
    temp = num;
    while (num > 0)
    {
        rem = num % 10;
        num = num / 10;
        printf("%d", rem);
    }

    return 0;
}