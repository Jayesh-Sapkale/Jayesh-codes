#include <stdio.h>

int fibo(int a)
{
    int arr[a];
    arr[0] = 0;
    arr[1] = 1;

    printf("%d %d ", arr[0], arr[1]);
    for (int i = 2; i < a; i++)
    {
        arr[i] = arr[i - 2] + arr[i - 1];
        printf("%d ", arr[i]);
    }
}


int main()
{
    int num;

    printf("Enter a number: ");
    scanf("%d", &num);

    fibo(num);

    // int num, num1 = 0, num2 = 1, next, stop;

    // printf("Enter a number: ");
    // scanf("%d", &num);

    // printf("Enter a number until which you want to print: ");
    // scanf("%d", &stop);

    // printf("%d %d ", num1, num2);
    // next = num1 + num2;

    // for (int i = 2; i < num; i++)
    // {
    //     printf("%d ", next);

    //     num1 = num2;
    //     num2 = next;
    //     next = num1 + num2;
    // }

    // num1 = 0;
    // num2 = 1;

    // printf("\n");
    // printf("%d %d ", num1, num2);

    // next = num1 + num2;
    // while (next < stop)
    // {
    //     printf("%d ", next);
    //     num1 = num2;
    //     num2 = next;
    //     next = num1 + num2;
    // }
    return 0;
}