#include <stdio.h>

void display(int arr[], int size)
{
    printf("Displaying array: \n");
    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

void insert(int arr[], int size, int element, int capacity, int index)
{
    if (size <= capacity)
        for (int i = size - 1; i >= index; i--)
        {
            arr[i + 1] = arr[i];
        }
    arr[index] = element;
}

void delete (int arr[], int size, int element)
{
    int count;
    for (int i = 0; i < size; i++)
    {
        if (arr[i] == element)
        {
            size--;
            arr[i] == arr[i - 1];
        }
        else
        {
            count = 0;
        }
    }

    printf("current size of an array is: %d\n", size);

    if (count == 0)
    {
        printf("%d is not found\n", element);
    }
}

int main()
{
    int arr[100] = {1, 2, 4, 3, 5};

    int size = 5, capacity = sizeof(arr), element = 54, index = 1;

    display(arr, size);
    insert(arr, size, element, capacity, index);
    display(arr, size);

    return 0;
}