#include <stdio.h>
#include <ctype.h>

int main()
{
    char c;

    printf("Press U for Upper Case and L for Lower Case: ");
    scanf("%c", &c);

    c = tolower(c);
    if (c == 'u')
    {

        printf("Alphabets in Upper case: \n");

        for (c = 'A'; c <= 'Z'; c++)
        {
            printf("%c ", c);
        }
    }
    else if (c == 'l')
    {
        printf("Alphabets in Lower case: \n");

        for (c = 'a'; c <= 'z'; c++)
        {
            printf("%c ", c);
        }
    }
    else
    {
        printf("Invalid Choice!");
    }

    return 0;
}