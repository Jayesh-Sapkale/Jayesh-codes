#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main()
{

    /* Enter your code here. Read input from STDIN. Print output to STDOUT */

    int num, count_0 = 0, count_1 = 0, count_2 = 0, count_3 = 0, count_4 = 0, count_5 = 0, count_6 = 0, count_7 = 0, count_8 = 0, count_9 = 0;

    printf("Enter a number:");

    scanf("%d", &num);

    char c[num];

    for (int i = 0; i < num; i++)
    {
        scanf("%c", &c[i]);
    }

    for (int i = 0; i < num; i++)
    {
        if (c[i] = 0)
        {
            count_0++;
        }
        else if (c[i] == 1)
        {
            count_1++;
        }
        else if (c[i] == 2)
        {
            count_2++;
        }
        else if (c[i] == 3)
        {
            count_3++;
        }
        else if (c[i] == 4)
        {
            count_4++;
        }
        else if (c[i] == 5)
        {
            count_5++;
        }
        else if (c[i] == 6)
        {
            count_6++;
        }
        else if (c[i] == 7)
        {
            count_7++;
        }
        else if (c[i] == 8)
        {
            count_8++;
        }
        else if (c[i] == 9)
        {
            count_9++;
        }
    }

    printf("%d %d %d %d %d %d %d %d %d", count_0, count_1, count_2, count_3, count_4, count_5, count_6, count_7, count_8, count_9);
    return 0;
}
