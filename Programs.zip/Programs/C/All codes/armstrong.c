#include <stdio.h>

int is_armstrong(int a)
{
    int temp, sum = 0, rem;

    temp = a;

    while (a > 0)
    {
        rem = a % 10;
        sum += rem * rem * rem;
        a = a / 10;
    }
    a = temp;

    if (a == sum)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int main()
{
    int a, b;

    printf("Enter two number: ");
    scanf("%d%d", &a, &b);

    for (int i = a; i <= b; i++)
    {
        if (is_armstrong(i) == 1)
        {
            printf("%d ", i);
        }
    }

    return 0;
}