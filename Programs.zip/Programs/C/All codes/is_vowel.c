#include <stdio.h>
#include <ctype.h>
int main()
{
    int count;
    char c, vowel[] = {'a', 'e', 'i', 'o', 'u'}, result;

    printf("Enter a character: \n");
    scanf("%c", &c);

    result = tolower(c);

    for (int i = 0; i < 5; i++)
    {
        if (result == vowel[i])
        {
            count = 1;
        }
    }

    if (count == 1)
    {
        printf("%c is a vowel.\n", c);
    }
    else
    {
        printf("%c is a consonant.\n", c);
    }

    return 0;
}