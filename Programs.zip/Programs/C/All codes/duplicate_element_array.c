#include <stdio.h>

int main()
{
    int num, count = 0;

    printf("Enter size of an array: ");
    scanf("%d", &num);

    int arr[num];

    printf("Enter array elements: \n");

    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("\nArray elements are: \n");

    for (int i = 0; i < num; i++)
    {
        printf("%d ", arr[i]);
        for (int j = i + 1; j < num; j++)
        {
            if (arr[i] == arr[j])
            {
                count++;
            }
        }
    }

    printf("\nDuplicate elements in the array are: %d\n", count);

    return 0;
}