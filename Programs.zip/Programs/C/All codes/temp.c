#include <stdio.h>

void display(int arr[], int len)
{
    printf("\nDisplaying stack elements: \n");
    for (int i = 0; i < len; i++)
    {
        printf("%d ", arr[i]);
    }
}

int is_full(int arr[], int len, int size)
{
    if (len >= size)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int is_empty(int arr[], int len, int size)
{
    if (len == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void push(int arr[], int len, int size)
{
    int element;

    printf("\nEnter a element you want to insert: ");
    scanf("%d", &element);
    if (is_full(arr, len, size))
    {
        printf("\nStack is Full\n");
    }
    else
    {
        len++;
        arr[len] = element;
    }
}

void pop(int arr[], int len, int size)
{
    if (is_empty(arr, len, size))
    {
        printf("\nStack is Empty\n");
    }
    else
    {
        len--;
    }
}

int main()
{
    int size = 100;
    int arr[size], len, num;

    printf("Enter length of an array: ");
    scanf("%d", &len);

    printf("Enter array elements: \n");
    for (int i = 0; i < len; i++)
    {
        scanf("%d", &arr[i]);
    }

    display(arr, len);
    push(arr, len, size);
    display(arr, len);


    return 0;
}