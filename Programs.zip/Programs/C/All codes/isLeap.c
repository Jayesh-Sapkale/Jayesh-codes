#include <stdio.h>

int main()
{
    int num;

    printf("Enter a number: \n");
    scanf("%d", &num);

    if (num % 400 == 0)
    {
        printf("%d is a Leap year.\n", num);
    }
    else if (num % 100 == 0)
    {
        printf("%d is not a Leap year.\n", num);
    }
    else if (num % 4 == 0)
    {
        printf("%d is a Leap year.\n", num);
    }
    else
    {
        printf("%d is not a Leap year.\n", num);
    }

    return 0;
}