#include <stdio.h>

int main()
{
    float a, b, product;

    printf("Enter two floating points number: \n");

    scanf("%f %f", &a, &b);

    product = a * b;

    printf("%.1f X %.1f = %.2f", a, b, product);
    return 0;
}