#include <stdio.h>

int main()
{
    int num, data, count;

    printf("Enter a size of an array: ");
    scanf("%d", &num);

    int arr[num];

    printf("Enter elements of an array: \n");
    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("Enter a value you want to search: ");
    scanf("%d", &data);

    for (int i = 0; i < num; i++)
    {
        if (arr[i] == data)
        {
            printf("%d is at index %d", data, i);
            break;
        }
        else
        {
            count = 0;
        }
    }

    if (count = 0)
    {
        printf("%d is not found\n", data);
    }
    return 0;
}