#include <stdio.h>

void swap(int *, int *);

int main()
{
    int *c, *d;


    printf("Enter two numbers: ");
    scanf("%d%d", &c, &d);

    printf("value before swapping a = %d and b=%d\n", c, d);

    swap(&c, &d);
    printf("value after swapping a = %d and b=%d\n", c,d);

    return 0;
}

void swap(int *a, int *b)
{
    int temp;

    temp = *a;
    *a = *b;
    *b = temp;
}

