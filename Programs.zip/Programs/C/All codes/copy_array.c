#include <stdio.h>

int main()
{
    int num;

    printf("Enter size of an array: ");
    scanf("%d", &num);

    int arr[num], copy[num];

    printf("Enter elements of an array: \n");

    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }

    printf("\nElements of an array 1 are: \n");

    for (int i = 0; i < num; i++)
    {
        printf("%d ", arr[i]);
    }

    printf("\nElements of an array 2 are: \n");

    for (int i = 0; i < num; i++)
    {
        copy[i] = arr[i];
        printf("%d ", copy[i]);
    }

    return 0;
}