#include <stdio.h>

void swap(int *ptr1, int *ptr2)
{
    int temp = *ptr1;
    *ptr1 = *ptr2;
    *ptr2 = temp;
}

void arr_input(int size, int arr[])
{
    printf("Enter array elements: \n");
    for (int i = 0; i < size; i++)
    {
        scanf("%d", &arr[i]);
    }
}

void arr_display(int size, int arr[])
{
    printf("\nArray elements are: \n");
    for (int i = 0; i < size; i++)
    {
        printf("%d ", arr[i]);
    }
}

void arr_sort(int num, int arr[])
{
    for (int i = 0; i < num; i++)
    {
        for (int j = i + 1; j < num; j++)
        {
            if (arr[j] < arr[i])
            {
                swap(&arr[i], &arr[j]);
            }
        }
    }
}

void arr_asc(int num, int arr[])
{
    printf("\nArray in Ascending order: \n");
    for (int i = 0; i < num; i++)
    {
        printf("%d ", arr[i]);
    }
}

void arr_desc(int num, int arr[])
{
    printf("\nArray in Descending order: \n");
    for (int i = num - 1; i >= 0; i--)
    {
        printf("%d ", arr[i]);
    }
}
int main()
{
    int num;

    printf("Enter size of an array: ");
    scanf("%d", &num);

    int arr[num];

    arr_input(num, arr);
    arr_display(num, arr);
    arr_sort(num, arr);
    arr_asc(num, arr);
    arr_desc(num, arr);

    return 0;
}
