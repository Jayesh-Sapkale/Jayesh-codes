#include <stdio.h>

int main()
{
    int num, result = 0;

    printf("Enter a number: ");
    scanf("%d", &num);

    int arr[num];

    printf("Enter array elements: \n");

    for (int i = 0; i < num; i++)
    {
        scanf("%d", &arr[i]);
    }

    for (int i = 0; i < num; i++)
    {
        printf("%d ", arr[i]);
    }

    for (int i = 0; i < num; i++)
    {
        result += (2 ^ i) * arr[i];
    }

    printf("\nresult: %d\n", result);

    return 0;
}