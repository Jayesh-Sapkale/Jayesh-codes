#include <stdio.h>
#include <string.h>

int main()
{
    int num, count = 0;
    char temp[4] = "010";

    printf("Enter size of a string: ");
    scanf("%d", &num);
    char str[num];
    printf("Enter string: \n");
    for (int i = 0; i < num; i++)
    {
        scanf(" %c", &str[i]);
    }
    for (int i = 0; i < num; i++)
    {
        if (strcmp(str,temp) == 1)
        {
            str[i] = '1';
            count++;
        }
        printf("%c", str[i]);
    }

    printf("\ncount: %d", count);

    return 0;
}