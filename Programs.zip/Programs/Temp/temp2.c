#include <stdio.h>

int main()
{
    char str1[10], str2[10];
    int i = 0;

    printf("Enter your string: ");
    for (i = 0; i < 10; i++)
    {
        scanf(" %c", &str1[i]);
    }

    printf("Your String is: ");
    for (i = 0; i < 10; i++)
    {
        printf("%c", str1[i]);
    }

    while (str1[i] != '\0')
    {
        str2[i] = str1[i];
        i++;
    }

    printf("\nSecond string is: ");
    for (i = 0; i < 10; i++)
    {
        printf("%c", str2[i]);
    }

    return 0;
}