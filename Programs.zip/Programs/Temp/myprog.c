#include <stdio.h>
#include<math.h>

int main()
{
    int rem = fmod(3.14, 2.1);

    printf("%d", rem);

    return 0;
}